/*exports.cal = () =>{
    add = (a,b) =>{
        return "Addition is " + (a+b)
    }
    
    sub = (a,b) =>{
        return "Sucbraction is " + (a-b)
    }

    mul = (a,b) =>{
        return "Multiplication is " + (a*b)
    }
    
    div = (a,b) =>{
        return "Division is " + (a/b)
    }

    square = (a) =>{
        return "Square is " + (a*a)
    }

    sum = (a,b,c,d) =>{
        return "Sum is " + Math.sum(a,b,c,d)
    }

    min = (a,b,c,d) =>{
        return "Minimum is " + Math.min(a,b,c,d)
    }

    max = (a,b,c,d) =>{
        return "Maximum is " + Math.max(a,b,c,d)
    }
}*/

exports.add = (a,b) =>{
    return "Addition is " + (a+b)
}

exports.sub = (a,b) =>{
    return "Subraction is " + (a-b)
}

exports.mul = (a,b) =>{
    return "Multiplication is " + (a*b)
}

exports.div = (a,b) =>{
    return "Division is " + (a/b)
}

exports.square = (a) =>{
    return "Square is " + (a*a)
}

exports.sum1 = (a,b,c,d) =>{
    return "Sum is " + (a+b+c+d)
}

exports.min1 = (a,b,c,d) =>{
    return "Minimum is " + (Math.min(a,b,c,d))
}

exports.max1 = (a,b,c,d) =>{
    return "Maximum is " + (Math.max(a,b,c,d))
}

