var mod1 = require("./Module1")

console.log(mod1.stuname,mod1.age)


mod1.greetInEng()
mod1.greetInSapnish()

console.log(mod1.add(5,5))