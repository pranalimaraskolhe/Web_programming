
function convert(){
    var distance = parseInt(prompt("Enter the distance: "))
    var distance_in_cm = 2.54 * distance

    //console.log(distance_in_cm)
    document.write(distance_in_cm)
}

